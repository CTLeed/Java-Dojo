package com.codingdojo.zoo;

public class GorillaTest {

	public static void main(String[] args) {
		Gorilla kong = new Gorilla();
		
		kong.throwSomething();
		kong.throwSomething();
		kong.throwSomething();
		kong.eatBananas();
		kong.eatBananas();
		kong.climb();
	}

}
