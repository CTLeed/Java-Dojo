package com.codingdojo.car;

public class Car {
	protected int gas;

	public Car() {
		this.gas = 10;
	}
	
	public int displayGas() {
		return this.gas;
	}
	
}
