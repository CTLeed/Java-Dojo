package com.codingdojo.car;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Driver driver1 = new Driver();
		
		driver1.drive();
		driver1.drive();
		driver1.drive();
		driver1.drive();
		driver1.boost();
		driver1.refuel();
		driver1.refuel();
		driver1.refuel();
	}

}
